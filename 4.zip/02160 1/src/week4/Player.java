package week4;

public class Player {
    
int checkers = 12; // total amout of checkers for player 1
// remember that turn is a char
char turn = '1';     // var to keep track of the players turn
// we need to create a constructor
public Player (char turn){
this.turn = turn ;

}//end constructor

}// end player