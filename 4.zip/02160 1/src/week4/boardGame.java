package week4;

public interface boardGame {

	public void initialize();
	
	public void display();
	
	public void getMove();
	
}
