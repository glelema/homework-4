package week4;
import java.util.Scanner;

public class Board implements boardGame, Piece {
static char[][] board = new char[8][8];// create a class board
static char turn= '1';// we have to assign it somehow
Player p1 ;
Player p2 ;

// Constructor
public Board(Player p1 ,Player p2 ){
this.p1 = p1 ;
this.p2 = p2 ;
}





 // function to initialize the board
 @Override
 public void initialize(){ 
        
	for (int x = 0 ; x < 8 ; x++)
	    for (int y = 0 ; y < 8 ; y++)
		board[x][y] = ' ';
        
        for (int x = 0 ; x < 8 ; x++){
        if( x % 2 == 0){
           board[x][1] = '1';
	   board[x][5] = '2';
	   board[x][7] = '2';
           
        }
        else {
           board[x][0] = '1';
	   board[x][2] = '1';
	   board[x][6] = '2';
        }    
        }// end for
        }// end initialize
  
 // method to print out the board
      
 
 
 
 	@Override
    public void display() {
	 
	System.out.println("     0 1 2 3 4 5 6 7   <- X axis");
        System.out.println("    +----------------+");
	for (int y = 0 ; y < 8 ; y++) {
           
            System.out.printf("%d   |",y);
	    
	    for (int x = 0 ; x < 8 ; x++) {
		System.out.print(board[x][y] + " ");
               
	    }
	    System.out.print("|");
            System.out.println();
            
	}
	System.out.println("    +----------------+");
    }// end display
 
    
    
    
    
    
// checking for validity of the move
   @Override
   public int isvalid(int xfrom,int yfrom,int xto, int yto) {

	
	// cheking if the values are in the range
	if (xfrom < 0 || xfrom > 7 || yfrom < 0 || yfrom > 7 ||
	    xto < 0 || xto > 7 || yto < 0 || yto > 7) 
	    return 0;

	//for a move to be valid it has to be the players checker
        // and the players move
	else if (Board.board[xfrom][yfrom] == turn && Board.board[xto][yto]==' ') {

	    // moving by 1 case
	    if (Math.abs(xfrom-xto) == 1) {
		if ((turn == '1') && (yto - yfrom == 1))
		    return 1;
		else if ((turn == '2') && (yto - yfrom == -1))
		    return 1;
	    }
	    
	    // jumping
            // we have to check that we end up in the right coordinates
            // and that we jump over the opposite player's checker
	    else if (Math.abs(xfrom-xto) == 2) {
		if (turn == '1' && (yto - yfrom == 2) && 
		    Board.board[(xfrom+xto)/2][(yfrom+yto)/2] == '2')
		    return 1;
		else if (turn == '2' && (yto - yfrom == -2) && 
		    Board.board[(xfrom+xto)/2][(yfrom+yto)/2] == '1')
		    return 1;
	    }
	}
	
	return 0;
    }// end isvalid



   
   
   
   
   
   
// function to move the player's checker
 @Override
 public void getMove() {
	
	Scanner input = new Scanner(System.in);

	if (turn=='1')
	    System.out.println("Turn of player no. 1");
	else
	    System.out.println("Turn of player no. 2");
	int played = 0; // played is used as a flag 
	
	while (played == 0) {
	    
	    System.out.println("Coordinate of piece to move : ");
            System.out.println("Enter X : ");
	    int xfrom = input.nextInt();
            System.out.println("Enter Y : ");
            int yfrom = input.nextInt();

	    System.out.println("Coordinates of new position :");
	    System.out.println("Enter X : ");
	    int xto = input.nextInt();
            System.out.println("Enter Y : ");
            int yto = input.nextInt();
           

	    // isvalid and move have only an internal call
	    if (1 == isvalid(xfrom,yfrom,xto,yto) ) {
		move(xfrom,yfrom,xto,yto);
		played = 1;
	    }
	    else
		System.out.println("try again invalid move.");
	}

	// switching the turn
	if (turn == '1')
	    turn = '2';
	else
	    turn = '1';
    }// end getnextmove

 
 


 
 
 
// function that actually move the checker
   @Override
   public void move(int xfrom,int yfrom,int xto, int yto) {
	// erasing the checker
	Board.board[xfrom][yfrom] = ' ';
        // updating it in the next case
	Board.board[xto][yto] = turn;
	
        if (Math.abs(xto - xfrom) == 2) {
            // oposite player's checker lost
	    Board.board[(xfrom+xto)/2][(yfrom+yto)/2] = ' ';
           
        if (Board.turn == p1.turn)
	p1.checkers--;
        else
        p2.checkers--;	
        
        }
            
    }// end move 





@Override
public int isvalid() {
	// TODO Auto-generated method stub
	return 0;
}
 
}// end board



