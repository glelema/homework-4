package week4;

public class Checkers {


	  public static void main(String args[]) {

		
		// initialize 2 players
	        Player p1 = new Player('1');
	        Player p2 = new Player('2');
	        Board game = new Board(p1,p2);
	        
	        //initialize and display the board
	        game.initialize(); 
		game.display();
		do{
	            // called on each player
	            game.getMove();
	            // call on the board
		    game.display();
	         // continue the game while no player have run out
	         // of checkers
	        }while(p1.checkers != 0 && p2.checkers != 0);
	        // once one of the players run out of checkers
	        // we check which one
	        // and display that the other one won
	        if(p1.checkers == 0)
	        System.out.println(" The Winner is player 2");
	          
	        else if(p2.checkers == 0)
	        System.out.println(" The Winner is player 1");
	        
	     }// end main      

	    
	}// end Checker