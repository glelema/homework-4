package week4;

public interface Piece {

	public int isvalid();

	void move(int xfrom, int yfrom, int xto, int yto);
	
	public int isvalid(int xfrom, int yfrom, int xto, int yto);
	
}
